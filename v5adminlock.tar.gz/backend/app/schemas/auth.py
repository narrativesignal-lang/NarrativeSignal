from __future__ import annotations

from pydantic import BaseModel, Field, field_validator


class RegisterRequest(BaseModel):
    """Username allows Unicode; no spaces or @ (email is derived as username@user.local)."""

    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=8, max_length=200)

    @field_validator("username")
    @classmethod
    def username_normalized(cls, v: str) -> str:
        s = (v or "").strip().lower()
        if len(s) < 2:
            raise ValueError("Username must be at least 2 characters")
        if len(s) > 80:
            raise ValueError("Username is too long")
        if any(ch in s for ch in "@ \t\n\r"):
            raise ValueError("Username cannot contain spaces or @")
        return s


class LoginRequest(BaseModel):
    username: str  # username or email
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class MeResponse(BaseModel):
    id: str
    username: str
    email: str  # str not EmailStr: admin@internal.test etc. may fail strict validation
    credits_balance: int
    paid_access: bool = False
    is_admin: bool = False

