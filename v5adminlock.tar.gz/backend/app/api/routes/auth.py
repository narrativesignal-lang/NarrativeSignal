from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from jose import JWTError
from sqlalchemy import select, func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, user_is_admin
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)
from app.db.session import get_db
from app.models.user import User
from app.schemas.auth import LoginRequest, MeResponse, RegisterRequest, TokenResponse


router = APIRouter()
REFRESH_COOKIE_NAME = "narrative_refresh"


@router.post("/register", response_model=MeResponse)
def register(payload: RegisterRequest, db: Session = Depends(get_db)) -> MeResponse:
    username = payload.username
    existing = db.scalar(select(User).where(func.lower(User.username) == username))
    if existing:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already exists")

    # Email derived from username for now (no separate email in registration)
    email = f"{username}@user.local"
    if db.scalar(select(User).where(User.email == email)):
        email = f"{username}+{uuid.uuid4().hex[:8]}@user.local"
    user = User(
        username=username,
        email=email,
        password_hash=hash_password(payload.password),
        credits_balance=10_000,
        token_version=0,
    )
    db.add(user)
    try:
        db.commit()
        db.refresh(user)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already exists")
    return MeResponse(
        id=str(user.id),
        username=user.username,
        email=user.email,
        credits_balance=user.credits_balance,
        paid_access=getattr(user, "paid_access", False),
        is_admin=user_is_admin(user),
    )


def _resolve_user(db: Session, login: str) -> User | None:
    """Look up user by username or email. 'admin' maps to admin@internal.test."""
    login = login.strip().lower()
    if not login:
        return None
    if login == "admin":
        return db.scalar(select(User).where(User.username == "admin"))
    by_username = db.scalar(select(User).where(func.lower(User.username) == login))
    if by_username:
        return by_username
    return db.scalar(select(User).where(func.lower(User.email) == login))


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, response: Response, db: Session = Depends(get_db)) -> TokenResponse:
    user = _resolve_user(db, payload.username)
    if not user or not verify_password(payload.password.strip(), user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    # Single session: increment token_version to invalidate previous sessions
    user.token_version = getattr(user, "token_version", 0) + 1
    db.commit()
    db.refresh(user)
    ver = getattr(user, "token_version", 0)

    access = create_access_token(subject=user.username, user_id=str(user.id), token_version=ver)
    refresh = create_refresh_token(subject=user.username, user_id=str(user.id), token_version=ver)
    response.set_cookie(
        key=REFRESH_COOKIE_NAME,
        value=refresh,
        httponly=True,
        samesite="lax",
        secure=False,
        path="/api/auth",
        max_age=60 * 60 * 24 * 30,
    )
    return TokenResponse(access_token=access)


@router.post("/refresh", response_model=TokenResponse)
def refresh(request: Request, response: Response, db: Session = Depends(get_db)) -> TokenResponse:
    token = request.cookies.get(REFRESH_COOKIE_NAME)
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing refresh token")
    try:
        payload = decode_token(token)
        if payload.get("typ") != "refresh":
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token type")
        uid = payload.get("uid")
        if not uid:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload")
        user_id = uuid.UUID(uid)
    except (JWTError, ValueError):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid refresh token")

    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")

    # Single-session: reject refresh if session was invalidated (new login)
    current_ver = getattr(user, "token_version", 0)
    token_ver = payload.get("ver", 0)
    if token_ver != current_ver:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Your session has expired because your account was signed in somewhere else.",
        )

    access = create_access_token(subject=user.username, user_id=str(user.id), token_version=current_ver)
    refresh = create_refresh_token(subject=user.username, user_id=str(user.id), token_version=current_ver)
    response.set_cookie(
        key=REFRESH_COOKIE_NAME,
        value=refresh,
        httponly=True,
        samesite="lax",
        secure=False,
        path="/api/auth",
        max_age=60 * 60 * 24 * 30,
    )
    return TokenResponse(access_token=access)


@router.post("/logout")
def logout(response: Response) -> dict:
    response.delete_cookie(key=REFRESH_COOKIE_NAME, path="/api/auth")
    return {"ok": True}


@router.get("/me", response_model=MeResponse)
def me(current_user: User = Depends(get_current_user)) -> MeResponse:
    return MeResponse(
        id=str(current_user.id),
        username=getattr(current_user, "username", current_user.email),
        email=current_user.email,
        credits_balance=current_user.credits_balance,
        paid_access=getattr(current_user, "paid_access", False),
        is_admin=user_is_admin(current_user),
    )

